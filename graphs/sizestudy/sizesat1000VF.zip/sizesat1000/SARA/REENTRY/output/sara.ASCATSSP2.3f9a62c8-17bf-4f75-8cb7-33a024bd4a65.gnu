 
set datafile separator whitespace
set term png size 960,480
 
set o 'sara.ASCATSSP2.3f9a62c8-17bf-4f75-8cb7-33a024bd4a65_altitudeVsTime.png'
set size 1,1 
set origin 0,0
set grid
 
set key font ",14"
set title 'Altitude vs Time of ASCATSSP2 (3f9a62c8-17bf-4f75-8cb7-33a024bd4a65)' noenhanced font ",14"
set xlabel 'Time [s]' font ",14"
set ylabel 'Altitude [Km]' font ",14"
set tics font ",14"
set style line 1 lc rgb 'blue' lw 3 pt 1 ps 3
 
plot 'sara.ASCATSSP2.3f9a62c8-17bf-4f75-8cb7-33a024bd4a65_Trajectory.txt' using 1:2 w l ls 1 title 'ASCATSSP2' noenhanced, \
 
set o 'sara.ASCATSSP2.3f9a62c8-17bf-4f75-8cb7-33a024bd4a65_altitudeVsDownrange.png'
set size 1,1 
set origin 0,0
set grid
 
set key font ",14"
set title 'Altitude vs Downrange of ASCATSSP2 (3f9a62c8-17bf-4f75-8cb7-33a024bd4a65)' noenhanced font ",14"
set xlabel 'Downrange [Km]' font ",14"
set ylabel 'Altitude [Km]' font ",14"
set tics font ",14"
 
plot 'sara.ASCATSSP2.3f9a62c8-17bf-4f75-8cb7-33a024bd4a65_Trajectory.txt' using 6:2 w l ls 1 title 'ASCATSSP2' noenhanced
 
