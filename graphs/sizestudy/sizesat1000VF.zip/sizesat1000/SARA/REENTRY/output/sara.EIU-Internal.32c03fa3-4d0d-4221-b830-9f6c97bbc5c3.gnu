 
set datafile separator whitespace
set term png size 960,480
 
set o 'sara.EIU-Internal.32c03fa3-4d0d-4221-b830-9f6c97bbc5c3_altitudeVsTime.png'
set size 1,1 
set origin 0,0
set grid
 
set key font ",14"
set title 'Altitude vs Time of EIU-Internal (32c03fa3-4d0d-4221-b830-9f6c97bbc5c3)' noenhanced font ",14"
set xlabel 'Time [s]' font ",14"
set ylabel 'Altitude [Km]' font ",14"
set tics font ",14"
set style line 1 lc rgb 'blue' lw 3 pt 1 ps 3
 
plot 'sara.EIU-Internal.32c03fa3-4d0d-4221-b830-9f6c97bbc5c3_Trajectory.txt' using 1:2 w l ls 1 title 'EIU-Internal' noenhanced, \
 
set o 'sara.EIU-Internal.32c03fa3-4d0d-4221-b830-9f6c97bbc5c3_altitudeVsDownrange.png'
set size 1,1 
set origin 0,0
set grid
 
set key font ",14"
set title 'Altitude vs Downrange of EIU-Internal (32c03fa3-4d0d-4221-b830-9f6c97bbc5c3)' noenhanced font ",14"
set xlabel 'Downrange [Km]' font ",14"
set ylabel 'Altitude [Km]' font ",14"
set tics font ",14"
 
plot 'sara.EIU-Internal.32c03fa3-4d0d-4221-b830-9f6c97bbc5c3_Trajectory.txt' using 6:2 w l ls 1 title 'EIU-Internal' noenhanced
 
