 
set datafile separator whitespace
set term png size 960,480
 
set o 'sara.Ribpanel5.2d1ff1e5-d89d-41ec-9b30-c8806caa1207_altitudeVsTime.png'
set size 1,1 
set origin 0,0
set grid
 
set key font ",14"
set title 'Altitude vs Time of Ribpanel5 (2d1ff1e5-d89d-41ec-9b30-c8806caa1207)' noenhanced font ",14"
set xlabel 'Time [s]' font ",14"
set ylabel 'Altitude [Km]' font ",14"
set tics font ",14"
set style line 1 lc rgb 'blue' lw 3 pt 1 ps 3
 
plot 'sara.Ribpanel5.2d1ff1e5-d89d-41ec-9b30-c8806caa1207_Trajectory.txt' using 1:2 w l ls 1 title 'Ribpanel5' noenhanced, \
 
set o 'sara.Ribpanel5.2d1ff1e5-d89d-41ec-9b30-c8806caa1207_altitudeVsDownrange.png'
set size 1,1 
set origin 0,0
set grid
 
set key font ",14"
set title 'Altitude vs Downrange of Ribpanel5 (2d1ff1e5-d89d-41ec-9b30-c8806caa1207)' noenhanced font ",14"
set xlabel 'Downrange [Km]' font ",14"
set ylabel 'Altitude [Km]' font ",14"
set tics font ",14"
 
plot 'sara.Ribpanel5.2d1ff1e5-d89d-41ec-9b30-c8806caa1207_Trajectory.txt' using 6:2 w l ls 1 title 'Ribpanel5' noenhanced
 
