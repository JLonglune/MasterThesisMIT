 
set datafile separator whitespace
set term png size 960,480
 
set o 'sara.NIU-internal.6bf9e2de-89f5-4ecb-9051-4a6d99c869a2_altitudeVsTime.png'
set size 1,1 
set origin 0,0
set grid
 
set key font ",14"
set title 'Altitude vs Time of NIU-internal (6bf9e2de-89f5-4ecb-9051-4a6d99c869a2)' noenhanced font ",14"
set xlabel 'Time [s]' font ",14"
set ylabel 'Altitude [Km]' font ",14"
set tics font ",14"
set style line 1 lc rgb 'blue' lw 3 pt 1 ps 3
 
plot 'sara.NIU-internal.6bf9e2de-89f5-4ecb-9051-4a6d99c869a2_Trajectory.txt' using 1:2 w l ls 1 title 'NIU-internal' noenhanced, \
 
set o 'sara.NIU-internal.6bf9e2de-89f5-4ecb-9051-4a6d99c869a2_altitudeVsDownrange.png'
set size 1,1 
set origin 0,0
set grid
 
set key font ",14"
set title 'Altitude vs Downrange of NIU-internal (6bf9e2de-89f5-4ecb-9051-4a6d99c869a2)' noenhanced font ",14"
set xlabel 'Downrange [Km]' font ",14"
set ylabel 'Altitude [Km]' font ",14"
set tics font ",14"
 
plot 'sara.NIU-internal.6bf9e2de-89f5-4ecb-9051-4a6d99c869a2_Trajectory.txt' using 6:2 w l ls 1 title 'NIU-internal' noenhanced
 
