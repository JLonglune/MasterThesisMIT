 
set datafile separator whitespace
set term png size 960,480
 
set o 'sara.RTU-internal.5fcb2380-1d60-4ce0-bcbb-10b1e00c4e0d_altitudeVsTime.png'
set size 1,1 
set origin 0,0
set grid
 
set key font ",14"
set title 'Altitude vs Time of RTU-internal (5fcb2380-1d60-4ce0-bcbb-10b1e00c4e0d)' noenhanced font ",14"
set xlabel 'Time [s]' font ",14"
set ylabel 'Altitude [Km]' font ",14"
set tics font ",14"
set style line 1 lc rgb 'blue' lw 3 pt 1 ps 3
 
plot 'sara.RTU-internal.5fcb2380-1d60-4ce0-bcbb-10b1e00c4e0d_Trajectory.txt' using 1:2 w l ls 1 title 'RTU-internal' noenhanced, \
 
set o 'sara.RTU-internal.5fcb2380-1d60-4ce0-bcbb-10b1e00c4e0d_altitudeVsDownrange.png'
set size 1,1 
set origin 0,0
set grid
 
set key font ",14"
set title 'Altitude vs Downrange of RTU-internal (5fcb2380-1d60-4ce0-bcbb-10b1e00c4e0d)' noenhanced font ",14"
set xlabel 'Downrange [Km]' font ",14"
set ylabel 'Altitude [Km]' font ",14"
set tics font ",14"
 
plot 'sara.RTU-internal.5fcb2380-1d60-4ce0-bcbb-10b1e00c4e0d_Trajectory.txt' using 6:2 w l ls 1 title 'RTU-internal' noenhanced
 
