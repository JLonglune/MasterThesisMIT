load "oscar.alt.gnu"
